<h1 align="center">
  <br>
  <a href="https://github.com/cachecleanerjeet/Upier"><img src="https://firebasestorage.googleapis.com/v0/b/webtuhin.appspot.com/o/githubstatic%2Fupier.svg?alt=media&token=43bd247f-4737-40be-8a15-1a145a17652d" alt="Upier" width="300"></a>
</h1>
<h4 align="center"><a href="https://github.com/cachecleanerjeet/Upier" target="_blank">Upier</a> is a Free and Secure Plartform to Create & Share UPI Payment's Link
 <br> <br> <a href="https://upier.t-ps.net" align="center"><img src="https://img.shields.io/badge/create--a--payment--link-green?style=for-the-badge" alt="Upier" ></a>
</h4>

<br>
<br>

### Features:<br>

_i. Totally Free._<br>
_ii. Support Amount Set._<br>
_iii. Have QR Suppport for Scan & Pay._<br>
_iv. Works with all UPI App._<br>
_v. Cool and Easy to Use Interface._<br>

### Best uses:<br>

_This will help Local Businesses to recieve their Payment via UPI Link. Because this is [MIT Licenced ](https://github.com/cachecleanerjeet/Upier/blob/master/LICENSE "MIT Licenced ")you can customize it however you need & impliment on your Business._<br><br>

### Deploy: <br>

- Fork this Repo
- Goto <tt>https://vercel.com</tt>
- Connect with your Forked Repo
- Deploy
  <br>

**You can Customize it However you Like**👍. **But don't Forget to give a Footer Credit**😉.<br><br>

### Credits:

Idea from [Upayi](https://github.com/cyberboysumanjay/upayi "Upayi") by [Sumanjay](https://github.com/cyberboysumanjay/ "Sumanjay")<br>
Designed & Developed to [Me (Tuhin)](https://github.com/cachecleanerjeet "Me (Tuhin)")

<br><br>

<h3 align="center"># Go Cashless</h3>
<p align="center"> <b>Made in 🇮🇳 for 🇮🇳</b></p>
