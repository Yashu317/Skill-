const DYNAMIC_IMAGE_HOST = "https://pay.upilink.in/images/upilink.png"; //no slash
const LOGO_URL = "";

export default function metadataImage(text, fontsize) {
    if (!fontsize) fontsize = 50;
    return `${DYNAMIC_IMAGE_HOST}`;
}
