import type { NextPage } from "next";
import Link from "next/link";
import { useEffect } from "react";

const Footer: NextPage = () => {
  useEffect(() => {
    const handleShare = () => {
      const currentUrl = window.location.href;
      const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(
        currentUrl
      )}`;
      window.open(whatsappUrl, "_blank");
    };

    const shareLinkButton = document.getElementById("shareLinkButton");
    if (shareLinkButton) {
      shareLinkButton.addEventListener("click", handleShare);
    }

    return () => {
      if (shareLinkButton) {
        shareLinkButton.removeEventListener("click", handleShare);
      }
    };
  }, []);

  return (
    <footer className="footer">
      <h1 className="logo">upilink.in</h1>
      <p className="slogan">
        Pay with any{" "}
        <img
          src="/images/upi.svg"
          className="upilogo"
          width="40"
          alt="Upi Icon"
        />{" "}
        App.
      </p>
      <p className="tpf">
        Want to create payment links for your business? Visit{" "}
        <Link href="https://upilink.in" passHref>
          <a
            target="_blank"
            rel="pay.upilink.in"
            style={{ fontSize: "9px", fontWeight: "normal" }}
          >
            upilink.in
          </a>
        </Link>{" "}
        and get started instantly.
      </p>
      <p className="tuhin">
        {" "}
        <a
          href="http://upilink.in/?ref=footer"
          target="_blank"
          rel="noreferrer"
        ></a>
      </p>
      {/* Add the Tap to Share button as a button */}
      <div style={{ textAlign: "center" }}>
        <button
          id="shareLinkButton"
          style={{
            cursor: "pointer",
            textDecoration: "underline",
            fontWeight: "bold",
          }}
        >
          Share Link
        </button>
      </div>
    </footer>
  );
};

export default Footer;
